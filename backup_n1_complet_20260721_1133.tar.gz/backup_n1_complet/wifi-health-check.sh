#!/bin/bash
LOG=/var/log/wifi-health.log
THRESHOLD_MBIT=5    # seuil en dessous duquel on considere le lien degrade
IFACE=wlan1

echo "=== $(date) : verification sante WiFi ===" >> $LOG

# Recupere tous les debits tx des clients connectes
BITRATES=$(iw dev $IFACE station dump | grep "tx bitrate" | grep -oP '^\s*tx bitrate:\s*\K[0-9.]+')

if [ -z "$BITRATES" ]; then
    echo "Aucun client connecte, rien a verifier." >> $LOG
    exit 0
fi

DEGRADED=0
for RATE in $BITRATES; do
    RATE_INT=$(echo "$RATE" | cut -d. -f1)
    echo "Debit detecte : ${RATE} Mbit/s" >> $LOG
    if [ "$RATE_INT" -lt "$THRESHOLD_MBIT" ]; then
        DEGRADED=1
    fi
done

if [ "$DEGRADED" -eq 1 ]; then
    echo "Debit degrade detecte (< ${THRESHOLD_MBIT} Mbit/s). Redemarrage de hostapd." >> $LOG
    systemctl restart hostapd
    sleep 3
    echo "hostapd redemarre : $(systemctl is-active hostapd)" >> $LOG
else
    echo "Debits normaux, aucune action." >> $LOG
fi
