import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { collectDefaultMetrics, Registry } from 'prom-client';
import { AppModule } from '../app.module';
import { json, urlencoded } from 'express';
import { BusinessErrorFilter } from './filters/business-error.filter';

export async function bootstrap(): Promise<void> {
  const app = await NestFactory.create(AppModule);
  app.use(json({ limit: '15mb' }));
  app.use(urlencoded({ extended: true, limit: '15mb' }));
  const config = app.get(ConfigService);

  app.enableCors({
    origin: config.get<string[]>('cors.origins', ['http://localhost:3000']),
    credentials: true,
  });

  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
    }),
  );
  app.useGlobalFilters(new BusinessErrorFilter());
  app.setGlobalPrefix('api');

  const metricsRegistry = new Registry();
  collectDefaultMetrics({ register: metricsRegistry });
  const httpAdapter = app.getHttpAdapter().getInstance();
  httpAdapter.get('/metrics', async (_req: unknown, res: { set: (k: string, v: string) => void; end: (b: string) => void }) => {
    res.set('Content-Type', metricsRegistry.contentType);
    res.end(await metricsRegistry.metrics());
  });

  const port = Number(process.env.PORT) || 3000;
  await app.listen(port);

  console.log(`API passerelle: http://localhost:${port}/api`);
  console.log(`Metrics: http://localhost:${port}/metrics`);
}

