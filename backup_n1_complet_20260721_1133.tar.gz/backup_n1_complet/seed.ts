import { PrismaClient } from '@prisma/client';
import { hash } from 'bcryptjs';

const prisma = new PrismaClient();

async function main(): Promise<void> {
  const username = 'admin';
  const password = 'admin';
  const passwordHash = await hash(password, 10);

  await prisma.adminUserTable.upsert({
    where: { username },
    update: {
      password_hash: passwordHash,
    },
    create: {
      username,
      password_hash: passwordHash,
      email: 'admin@local',
    },
  });

  console.log(`Seeded admin user: username="${username}" password="${password}"`);
  console.log('Aucun faux utilisateur passerelle genere : les identites reelles proviennent de app-mobile.');
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
