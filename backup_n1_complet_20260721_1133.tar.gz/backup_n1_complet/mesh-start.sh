#!/bin/bash
LOG=/var/log/mesh-start.log
echo "=== $(date) : demarrage mesh-start (N1) ===" >> $LOG

# 1. Code pays + deblocage radio
iw reg set BF >> $LOG 2>&1
rfkill unblock all >> $LOG 2>&1
sleep 2

# 2. Neutralise tout wpa_supplicant residuel (cause du blocage -114 vu en session)
systemctl stop wpa_supplicant 2>/dev/null
pkill -9 -f "wpa_supplicant" 2>/dev/null
sleep 1

# 3. Tue toute instance hostapd fantome avant de reconfigurer
pkill -9 -f "/usr/sbin/hostapd" 2>/dev/null
sleep 1

# 4. Libere wlan0 et wlan1 de NetworkManager
nmcli device set wlan0 managed no 2>/dev/null
nmcli device set wlan1 managed no 2>/dev/null
sleep 1

# 5. Monte l'IBSS sur wlan0 (mesh)
ip link set wlan0 down
iw dev wlan0 set type ibss
ip link set wlan0 up
sleep 2
iw dev wlan0 ibss join epo-mesh 2412
sleep 5
ip addr flush dev wlan0
ip addr add 10.0.0.1/24 dev wlan0
echo "IBSS wlan0 : $(iw dev wlan0 link)" >> $LOG

# 6. Configure wlan1 (point d'acces) - IP posee AVANT hostapd/dnsmasq
ip link set wlan1 down
iw dev wlan1 set type managed
ip link set wlan1 up
sleep 1
ip addr flush dev wlan1
ip addr add 10.0.1.1/24 dev wlan1
echo "IP wlan1 posee : $(ip -br addr show wlan1)" >> $LOG

# 7. Demarre hostapd et dnsmasq, dans cet ordre, apres l'IP
sleep 2
systemctl restart hostapd >> $LOG 2>&1
sleep 3
systemctl restart dnsmasq >> $LOG 2>&1
sleep 2

# 8. Routage : forward + NAT (la piece qui manquait en session)
sysctl -w net.ipv4.ip_forward=1 >> $LOG 2>&1
iptables -C FORWARD -i wlan1 -o wlan0 -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i wlan1 -o wlan0 -j ACCEPT
iptables -C FORWARD -i wlan0 -o wlan1 -j ACCEPT 2>/dev/null || \
  iptables -A FORWARD -i wlan0 -o wlan1 -j ACCEPT
iptables -t nat -C POSTROUTING -o wlan0 -j MASQUERADE 2>/dev/null || \
  iptables -t nat -A POSTROUTING -o wlan0 -j MASQUERADE

echo "=== $(date) : mesh-start (N1) termine ===" >> $LOG

# 9. Force une adresse link-local IPv6 sur IPv6 sur wlan0
sleep 5
ip -6 addr add fe80::1/64 dev wlan0 scope link >> $LOG 2>&1
sleep 2
echo "IPv6 wlan0 : $(ip -6 addr show wlan0 | grep fe80)" >> $LOG

systemctl restart babeld >> $LOG 2>&1
echo "Babel : $(systemctl is-active babeld)" >> $LOG
